package com.example.video10;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface MovieApi {
    @GET("v3/aaa3f7a1-23ce-491f-aac4-c118a4fed1e9")
    Call<List<Movie>> getMovies();
}
